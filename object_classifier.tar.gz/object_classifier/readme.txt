to run classifier

1)set imloc = TARGET IMAGE
2)run mainscript
3)pointsD2 is the set of points selected from image
4)in pcascript is the format for creating a new pca matrix with images and points as you see fit
4)fmat is the output which corresponds to the new PCA matrix
5)testscript is similar to pcascript except it uses the test images and creates a classification
	-the lines with the voter function are the classification lines, rename variables as you see 		 fit
